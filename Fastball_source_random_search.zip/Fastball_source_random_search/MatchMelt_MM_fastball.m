% place uncorrected composition here, not sure what last column is sup. to
% be about...
format short
Folder = cd;
Folder = fullfile(Folder, '..');
addpath(Folder)
filename = 'Fastball_fullrange'; % CHANGE THE NAME of where the succesful simulations are saved
load('Fastball_errorlarge_iso.mat') % SELECT the structure that you want to explore 
path = cd;
%% MELT COMPOSITION THAT YOU WANT TO MATCH
%           [SiO2   TiO2    Al2O3   Cr2O3   FeO     MnO     MgO     CaO     Na2O    K2O     P2O5]
MatchBulk = [48.32	0.71	8.37	0.52	18.99	0.50	12.80	6.19	2.51	0.25	0.84]; %Adirondack class
%tolerance = [0.5    0.05   0.15     -999    0.25     -999    0.25    0.15     0.07    0.03    0.05];
tolerance = [1.3    0.21   0.38     -999    0.85     -999    0.75    0.61     0.28    0.05    0.12];

% -999 indicates that the oxide is not used to discriminate 

% Match_range1 = 0.07; Match_range2 = 0.10; Match_range3 = 0.16;
% for now, I just match each oxide to a fixed uncertainty (e.g. 0.8 for SiO2)


% you can also choose to add some olivine to account for possible olivine
% fractionation
ns =1; %olivine add iterration 
%[1-2] for no olivine addition; [3] for 2.5 wt.% olivine addtion; [4] for 5 %;
%[5] for 7.5; [6] for 10 % [...]


Kd=0.35;
Frac=0.001;
%normalize
MatchBulk = [MatchBulk 0];
tot=sum(MatchBulk(1:end-1));
liqn=MatchBulk(1,1:end-1);
totn=sum(liqn);


olAdd_vector = [1,26,50,73,96,119,140, 161, 185, 203, 222, 241,260,279,299,315,330];
% modify composition by adding various amount of olivine from 
for j= olAdd_vector
    tot=sum(MatchBulk(1,1:end-1));
    liqn=MatchBulk(1,1:end-1);
    Frac=0.001;
for i= 1:j
    FeOvMgO=liqn(1,5)/liqn(1,7)*Kd; % FeO/MgO ratio of the olivine in equilibrium with liqn
    FeOol=liqn(1,5)/71.846; %molar proportion of FeO in olivine
    MgOol=liqn(1,5)/FeOvMgO/40.305; %molar proportion of MgO in olivine
    FeMgOl=FeOol+MgOol;
    FeOoln=FeOol/FeMgOl;
    MgOoln=MgOol/FeMgOl;
    FeOolw=FeOoln*71.846*2;%weight fraction of Fe in mineral formula
    MgOolw=MgOoln*40.305*2;%weight fraction of Mg in mineral formula
    SiO2olw=60.084;%weight fraction of Si in mineral formula
    olwtot=FeOolw+MgOolw+SiO2olw;
    ol=[SiO2olw/olwtot*100 0 0 0 FeOolw/olwtot*100 0 MgOolw/olwtot*100 0 0 0 0];
    liqn=(liqn+ol*Frac)/(1+Frac);
end


%olivine crystalized (in global wt% of the bulk)

Fractot=1;
tot=1;
for i=1:j-1
    Frac=Frac/(tot/(tot+Frac));
    Fractot=Fractot+Frac;
end
 MatchBulk = [MatchBulk ; [liqn Fractot]];
end


for k=1:size(MatchBulk,1)
    i=1;
matchrec(k).data = NaN*ones(1,size(allm(i).Final_table,2)+size(allm(i).End_P,2)+size(allm(i).Bulk_Comp,2)+size(MatchBulk(k,:),2));
matchrec(k).labels = {'Tp','Tp','Tp_batch','T_batch','SiO2','TiO2','Al2O3','Cr2O3','FeO','MnO','MgO','CaO','Na2O',...
                        'K2O','P2O5','melt F','P_start','P_end', 'SiO2_B','TiO2_B','Al2O3_B','Cr2O3_B','FeO_B','MnO_B',...
                        'MgO_B','CaO_B','Na2O_B','K2O_B','P2O5_B','SiO2_T','TiO2_T','Al2O3_T','Cr2O3_T','FeO_T','MnO_T',...
                        'MgO_T','CaO_T','Na2O_T','K2O_T','P2O5_T','Oliv_added'};
for i=1:size(allm,2)
    for j=1:size(allm(i).Final_table,1)
        if allm(i).Final_table(j,5) >= MatchBulk(k,1) - tolerance(1) && allm(i).Final_table(j,5) <= MatchBulk(k,1) + tolerance(1) &&...
        allm(i).Final_table(j,6) >= MatchBulk(k,2) - tolerance(2) && allm(i).Final_table(j,6) <= MatchBulk(k,2) + tolerance(2) &&...
        allm(i).Final_table(j,7) >= MatchBulk(k,3) - tolerance(3) && allm(i).Final_table(j,7) <= MatchBulk(k,3) + tolerance(3) &&...
        allm(i).Final_table(j,9) >= MatchBulk(k,5) - tolerance(5) && allm(i).Final_table(j,9) <= MatchBulk(k,5) + tolerance(5) &&...
        allm(i).Final_table(j,11) >= MatchBulk(k,7) - tolerance(7) && allm(i).Final_table(j,11) <= MatchBulk(k,7) + tolerance(7) &&...
        allm(i).Final_table(j,12) >= MatchBulk(k,8) - tolerance(8) && allm(i).Final_table(j,12) <= MatchBulk(k,8) + tolerance(8) &&...
        allm(i).Final_table(j,13) >= MatchBulk(k,9) - tolerance(9) && allm(i).Final_table(j,13) <= MatchBulk(k,9) + tolerance(9) &&...
        allm(i).Final_table(j,14) >= MatchBulk(k,10) - tolerance(10) && allm(i).Final_table(j,14) <= MatchBulk(k,10) + tolerance(10) &&...
        allm(i).Final_table(j,15) >= MatchBulk(k,11) - tolerance(11) && allm(i).Final_table(j,15) <= MatchBulk(k,11) + tolerance(11)
        matchrec(k).data = [matchrec(k).data; allm(i).Final_table(j,:) allm(i).End_P allm(i).Bulk_Comp MatchBulk(k,:)];
        end
    end
end
end

matchrec(ns).data

labelsForm = '%8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s\n';
dataForm = '%8.0f %8.0f %8.0f %8.0f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.3f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.1f\n';

fileID = fopen([filename '.txt'],'w');
fprintf(fileID,labelsForm,'Tp','Tp','Tp_batch','T_batch','SiO2','TiO2','Al2O3','Cr2O3','FeO','MnO','MgO','CaO','Na2O',...
                        'K2O','P2O5','melt_F','P_start','P_end', 'SiO2_B','TiO2_B','Al2O3_B','Cr2O3_B','FeO_B','MnO_B',...
                        'MgO_B','CaO_B','Na2O_B','K2O_B','P2O5_B','SiO2_T','TiO2_T','Al2O3_T','Cr2O3_T','FeO_T','MnO_T',...
                        'MgO_T','CaO_T','Na2O_T','K2O_T','P2O5_T','Oliv_added');
fprintf(fileID,dataForm,matchrec(ns).data');
fclose(fileID);