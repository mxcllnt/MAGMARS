clear all
tic
rng('shuffle') % schuffle seed for "true" randomness
Folder = cd;
Folder = fullfile(Folder, '..');
addpath(Folder)
%% Set variables here

% % polybaric melting variables
% Start_P = 5; 
% End_P_ini = 1.8; 
% End_P_range = 0.3; % range on End_P_ini 
% Tp_poly=[1300,10,1310]; %(Min, Increment, Max)

% isobaric melting variables
Start_P_iso = 1.2; 
P_iso_range = 0.1;

% general variables
simulN= 10000; %number of simulations

% PICK A NAME TO AVOID OVERWRITTING PREVIOUS CALCULATIONS
FName_iso='Fastball_error3_iso.mat';

% %% polybaric melting
KD = [4 0.35]; 
T_continuous = [0 1300];
plotit = 0; %0=false don't plot figure 9
% Tp_profile=Tp_poly(1):Tp_poly(2):Tp_poly(3);
% Tp_profile=[NaN Tp_profile];
% Iso_mode = 0; % 0 - polybaric
% 
% for i=1:simulN
% % vary End_P "randomly"
% End_P = End_P_ini; End_P = End_P + (rand()-1/2)*2*End_P_range;
% if End_P < 0.4
%     End_P = rand()/5+0.4;
% end
% 
% % vary Bulk_Comp "randomly"
% Bulk_Comp = Bulk_ini;
% 
% Bulk_Comp(1) = Bulk_Comp(1) + (rand()-1/2)*2 * Bulk_Comp(1) * 0.0;
% Bulk_Comp(3) = Bulk_Comp(3) + (rand()-1/2)*2 * Bulk_Comp(3) * Bulk_range1;
% Bulk_Comp(5) = Bulk_Comp(5) + (rand()-1/2)*2 * Bulk_Comp(5) * Bulk_range0;
% Bulk_Comp(8) = Bulk_Comp(8) + (rand()-1/2)*2 * Bulk_Comp(8) * Bulk_range2;
% Bulk_Comp(7) = Bulk_Comp(7) + (rand()-1/2)*2 * Bulk_Comp(7) * Bulk_range0;
% Bulk_Comp(2) = Bulk_Comp(2) + (rand()-1/2)*2 * Bulk_Comp(2) * Bulk_range1;
% Bulk_Comp(9) = Bulk_Comp(9) + (rand()-1/2)*2 * Bulk_Comp(9) * Bulk_range2; 
% Bulk_Comp(10) = Bulk_Comp(10) + (rand()-1/2)*2 * Bulk_Comp(10) * Bulk_range2;
% 
% Bulk_Comp = Bulk_Comp./sum(Bulk_Comp)*100; % renormalize Bulk...
% 
% %now run model with modified composition and End_P
% [Final_table] = MAGMARS_v1('DW',Start_P,End_P,Bulk_Comp,0.004,Tp_poly(1),Tp_poly(2),Tp_poly(3),Iso_mode,KD,T_continuous,plotit);
% 
% Tp_profileR = Tp_profile(size(Tp_profile,2)-size(Final_table.data,1)+1:end)';
% allm(i).Final_table=[Tp_profileR Final_table.data];
% allm(i).Bulk_Comp=Bulk_Comp;
% allm(i).End_P=End_P;
% close(figure(9))
% end
% 
% save(FName_poly, 'allm')
% clear allm

%% isobaric melting
Iso_mode= 1; % 1 - isobaric
for i=1:simulN
% vary End_P "randomly"
Start_P = Start_P_iso; Start_P = Start_P + (rand()-1/2)*2*P_iso_range;
End_P = Start_P;

% select same bulk comp as for isobaric
Al2O3_ini= 1.5 + round(7*abs((rand()-1/2)*1.5))/10; %asign a value of Al2O3 between 1.5 and 3 

Tp_ave=161.19*Al2O3_ini+1158.7;
Tp_ave=round(Tp_ave/10)*10;
Tp_iso=[Tp_ave-30,10,Tp_ave+30];

SiO2_ini = (-0.7051+0.09*(rand()-1/2)*2)*Al2O3_ini+46.96;
TiO2_ini = (0.1007+0.01007*(rand()-1/2)*2)*Al2O3_ini-0.0594;
Cr2O3_ini = (-0.152+0.0152*(rand()-1/2)*2)*Al2O3_ini+1.144;
FeO_ini = (0.5694+0.05694*(rand()-1/2)*2)*Al2O3_ini+15.47;
MnO_ini = (-0.0102+0.00102*(rand()-1/2)*2)*Al2O3_ini+0.4931;
MgO_ini = (-2.1845+0.25*(rand()-1/2)*2)*Al2O3_ini+36.64;
CaO_ini = (0.7042+0.07042*(rand()-1/2)*2)*Al2O3_ini+0.1179;
Na2O_ini = (0.4662+0.04662*(rand()-1/2)*2)*Al2O3_ini-0.5229;
K2O_ini = (0.054+0.0054*(rand()-1/2)*2)*Al2O3_ini-0.0695;
P2O5_ini = (0.1573+0.01573*(rand()-1/2)*2)*Al2O3_ini-0.1716;
Bulk_Comp = [SiO2_ini TiO2_ini Al2O3_ini Cr2O3_ini FeO_ini MnO_ini MgO_ini CaO_ini Na2O_ini K2O_ini P2O5_ini];

Bulk_Comp = Bulk_Comp./sum(Bulk_Comp)*100; % renormalize Bulk...

% now run model with modified composition and End_P
[Final_table] = MAGMARS_v1('DW',Start_P,End_P,Bulk_Comp,0.004,Tp_iso(1),Tp_iso(2),Tp_iso(3),Iso_mode,KD,T_continuous,plotit);
Tp_profile=Tp_iso(1):Tp_iso(2):Tp_iso(3); Tp_profile=[NaN Tp_profile];
Tp_profileR = Tp_profile(size(Tp_profile,2)-size(Final_table.data,1)+1:end)';
allm(i).Final_table=[Tp_profileR Final_table.data];
allm(i).Bulk_Comp=Bulk_Comp;
allm(i).End_P=End_P;
close(figure(9))
end

save(FName_iso, 'allm')
toc
