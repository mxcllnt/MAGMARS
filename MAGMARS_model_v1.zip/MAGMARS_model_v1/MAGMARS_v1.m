function [Final_table,Final_residue,detail_comp,detail_comp2] = MAGMARS_v1(name,Start_P,End_P,Bulk_Comp0,CMF,Tp_min,Tp_inc,Tp_max,Iso_mode,KD,T_continuous,plotit)
% requires the following functions: MM_modecalc.m and MM_reg.m (which itself requires WeighObs.m)
%   inputs: |0| Name (string)    |1| Start_P (in GPa)         |2| End_P (in GPa)
%           |3| Bulk_Comp (oxide vector, wt%, 1x11)  [SiO2 TiO2 Al2O3 Cr2O3 FeO MnO MgO CaO Na2O K2O P2O5]
%           |4| CMF = critical melt fraction (0.004-0.02)
%           |5,6,7| Tp_min, Tp_inc, Tp_max (�C) decompression melting along adiabat(s)
%               e.g. 1300,0,1300 for a single adiabat at 1300, etc.
%           |8| Iso_mode 1 (True) or 0 (False); default (False) = polybaric
%           |9| KD [4,0.35] is recommended (see doc), or [2,0.35]
%           |10| T_continuous. [0 X] no, except above temperature X -> harz. temperature
%               [1 X] yes always, optimized for harz. melting [2 X] optimized for lherz, not recommended for high melt fractions
%               default: [0 1300]
%           |11| plotit = 1, then plot figure, = 0 don't plot for better perf.

[SiO2_coeff,SiO2_coeff2,CaO_coeff,CaO_coeff2,FeO_coeff,FeO_coeff2,MgO_coeff,MgO_coeff2,Cr2O3_coeff,Cr2O3_coeff2,T_coeff,T_coeff2] = MM_reg(T_continuous);

% initialization 1
Bulk_Comp0=Bulk_Comp0/sum(Bulk_Comp0)*100; %normalize bulk composition
if Tp_inc<=0
    Tp_inc=1;
end
F_terminal=[NaN 1];
liq_ext_term=NaN*ones(1,11);
res_mantle=NaN*ones(1,11);
F2=0; %melt fraction harzburgite melting
F3=0; %melt fraction dunite melting
T_terminal=NaN;P_inters=NaN;P_inters2=NaN;
jj=1; %init. increment index for saving results from each adiabat in a structure

for Tp_Mantle=Tp_min:Tp_inc:Tp_max % solve for different mantle adiabat. 
    %% initialization 2
    LH=4e5;             %Latent Heat
    Cp=1e3;             %Specific heat
    Adiab=15;           %Adiabat gradient 15 �C / GPa
    Bulk_Comp = Bulk_Comp0; %reset bulk composition to input composition
    if (T_continuous(1)==0) && (Tp_Mantle > T_continuous(2))
        T_coeff=T_coeff2;
    end %use same thermometer for lherz and harz melting only if Tp is over a certain threshold: T_continuous(2)
    
    if Iso_mode == 1 % Iso_mode activated
        dP= 0.000005;
        if Start_P == End_P
            Start_P = Start_P + 0.007;
        else
            break
        end
    else
        dP= 0.001; % P increment in GPa [WARNING: if this value is too high (relative to F_inc) melting might "lag behind" during decompression, dP=0.001 and F_inc=0.001 shouldn't cause issues]
    end
    
    T = Tp_Mantle+Start_P*Adiab;    %set starting temperature
    T_start = T;
    F_inc= 0.001;       % melt fraction at which melt is evaluated (see below) [WARNING: do not increase further without also decreasing dP]
    
    % at begining F= F_inc, needed to calculate effective solidus temperature
    F_current=F_inc;
    F=F_inc;
    
    T_f2=NaN;
    wf=NaN*ones(1,11);
    wf2=NaN*ones(1,11);
    wf3=NaN*ones(1,11);
    liq_ext=zeros(1,11);
    
    %keeping track of P, T, F, mode and solid composition
    P_rec=NaN;
    T_rec=[NaN NaN NaN]; %T, T_f1, T_f2
    F_rec=[NaN NaN]; %F, F_current
    mode_eff_rec=[NaN NaN NaN NaN]; %Opx, Cpx, Sp, Oliv
    sol_rec=NaN*ones(1,11);% SiO2, TiO2, ... P2O5
    
    liq_inst_rec=NaN*ones(1,11); % composition of melt increments
    liq_ext_rec=zeros(1,11); % total composition of melt extracted
    
    % Calculate melting reaction coefficents
    % columns: 1_opx 2_cpx 3_spinel 4_oliv
    % lines: pressures 1, 1.5, 2 and 2.5 GPa
    Stoichio_Cf=[
        0.47 0.8 0.08 -0.35;
        -0.9 1.6 0.08 0.22;
        -1.2 1.9 0.08 0.22;
        -1.8 2.4 0.08 0.32];
    
    % Calculate mantle mode; optimized for DW85 composition (Collinet et al.
    % 2015)
    % but will be updated later with function MM_modecalc.m
    % so other mantle compositions can also be used
    % columns: 1_opx 2_cpx 3_spinel 4_oliv
    % lines: pressures 1, 1.5, 2 and 2.5 GPa
    start_mode=[
        46-12   12   2.5 100-46-2.5;
        46-27.2 27.2 2.5 100-46-2.5;
        46-34.2 34.2 2.5 100-46-2.5;
        46-38.4 38.4 2.5 100-46-2.5];
    
    start_mode=start_mode./sum(start_mode')'.*100;
    
    %% LOOP1 -- lherzolite melting
    for P=Start_P:-dP:End_P
        % at every pressure calculate "would be liquid composition" / "virtual liquid composition" (see documentation)
        % and use it to calculate a temperature = effective solidus.
        
        % First calculate, MgN of liquid (initial guess based on simple KD)
        MgN_sol=(Bulk_Comp(7)./40.3045)/(Bulk_Comp(5)./70.8464+Bulk_Comp(7)./40.3045);
        MgN_liq=1./((1./MgN_sol-1)/KD(2)+1)*100;
        
        %% update starting mode, based on pressure
        % when melting started F>F_inc, this is no longer necessary
        if F<=F_inc
            if P<=1
                start_mode_eff=start_mode(1,:);
            elseif (P>1) && (P<1.5)
                start_mode_eff=((P-1)/0.5).*start_mode(2,:)+(1-(P-1)/0.5).*start_mode(1,:);
            elseif P==1.5
                start_mode_eff=start_mode(2,:);
            elseif (P>1.5) && (P<2)
                start_mode_eff=((P-1.5)/0.5).*start_mode(3,:)+(1-(P-1.5)/0.5).*start_mode(2,:);
            elseif P==2.0
                start_mode_eff=start_mode(3,:);
            elseif (P>2.0) && (P<2.5)
                start_mode_eff=((P-2)/0.5).*start_mode(4,:)+(1-(P-2)/0.5).*start_mode(3,:);
            else
                start_mode_eff=start_mode(4,:);
            end
        end
        %% update melting coefficients for lherzolite melting, based on pressure (Collinet et al. 2015)
        Stoichio_Cf=Stoichio_Cf./sum(Stoichio_Cf')';
        if P<=1
            Stoichio_Cf_eff=Stoichio_Cf(1,:);
        elseif (P>1) && (P<1.5)
            Stoichio_Cf_eff=((P-1)/0.5).*Stoichio_Cf(2,:)+(1-(P-1)/0.5).*Stoichio_Cf(1,:);
        elseif P==1.5
            Stoichio_Cf_eff=Stoichio_Cf(2,:);
        elseif (P>1.5) && (P<2)
            Stoichio_Cf_eff=((P-1.5)/0.5).*Stoichio_Cf(3,:)+(1-(P-1.5)/0.5).*Stoichio_Cf(2,:);
        elseif P==2.0
            Stoichio_Cf_eff=Stoichio_Cf(3,:);
        elseif (P>2.0) && (P<2.5)
            Stoichio_Cf_eff=((P-2)/0.5).*Stoichio_Cf(4,:)+(1-(P-2)/0.5).*Stoichio_Cf(3,:);
        else
            Stoichio_Cf_eff=Stoichio_Cf(4,:);
        end
        %% Calculate partition coefficients, updated based on pressure
        % columns: 1_opx 2_cpx 3_spinel 4_oliv
        % lines: 1_Na 2_K 3_Al 4_P2O5 5_TiO2
        Part_Coeff=[
            NaN   NaN   1.1 0.01;
            0.003 0.003 0.8 0.001;
            NaN   NaN   2.5   NaN;
            0.01  0.01  0.1  0.08;
            0.1   NaN   1.5   0.03
            NaN   NaN   NaN   NaN];
        
        Part_Coeff(1,1)=0.0091*P^2+0.0054*P+0.0168; %D Na opx-liq
        Part_Coeff(1,2)=0.0158+0.0746*P;   %D Na cpx-liq
        Part_Coeff(3,1)=0.1614*P+0.0849; %D Al opx-liq
        Part_Coeff(3,2)=0.1877*P+0.0932; %D Al cpx-liq
        Part_Coeff(3,4)=0.0037*P+0.0024; %D Al oliv-liq
        Part_Coeff(5,2)=-0.0533*P+0.1952; %D Ti cpx-liq
        
        if (P>=1) && (P<=2.5)
            Part_Coeff(3,3)=1*P^2-3.1*P+3.2; %D Al Al-bearing phases
        elseif P<1
            Part_Coeff(3,3)=-4.8*P+5.9;
        else
            Part_Coeff(3,3)=1.72*P-2.6;
        end
        
        %% update mode, based on total px remaining and pressure
        if (F<=F_inc)
            mode_eff=start_mode_eff;
        else
            %update fraction of cpx at new pressure
            totpx=mode_eff(1)+mode_eff(2);
            if P<=1
                cpx_update=-26.62+0.8395*totpx;
            elseif (P>1) && (P<1.5)
                cpx_update=-560.8+854*P-137.5*P^2-184.9*P^3+19.19*totpx-36.21*P*totpx+17.93*P^2*totpx;
            elseif (P>=1.5) && (P<2)
                cpx_update=191.2-267.4*P-7.638*P^2-4.521*totpx+6.696*P*totpx;
            elseif (P>=2) && (P<2.5)
                cpx_update=620.5-482.3*P-7.822*P^2-13.96*totpx+11.43*P*totpx;
            elseif P>=2.5
                cpx_update=-645+14.86*totpx;
            end
            mode_eff(2)=cpx_update;
            mode_eff(1)=totpx-cpx_update;
            mode_eff=mode_eff./sum(mode_eff)*100;
        end
        
        %% calculate composition of melt
        
        % Bulk partition coefficents based on current mantle mode
        D_Na=Part_Coeff(1,:).*mode_eff./100;D_Na=sum(D_Na);
        D_K=Part_Coeff(2,:).*mode_eff./100;D_K=sum(D_K);
        D_Al=Part_Coeff(3,:).*mode_eff./100;D_Al=sum(D_Al);
        D_P=Part_Coeff(4,:).*mode_eff./100;D_P=sum(D_P);
        P_b_Na=Part_Coeff(1,:).*Stoichio_Cf_eff;P_b_Na=sum(P_b_Na);
        P_b_K=Part_Coeff(2,:).*Stoichio_Cf_eff;P_b_K=sum(P_b_K);
        P_b_Al=Part_Coeff(3,:).*Stoichio_Cf_eff;P_b_Al=sum(P_b_Al);
        P_b_P=Part_Coeff(4,:).*Stoichio_Cf_eff;P_b_P=sum(P_b_P);
        D_Ti=Part_Coeff(5,:).*mode_eff./100;D_Ti=sum(D_Ti);
        P_b_Ti=Part_Coeff(5,:).*Stoichio_Cf_eff;P_b_Ti=sum(P_b_Ti);
        
        % Batch melting equations
        C_l_Na2O=Bulk_Comp(9)./(D_Na+F_current/(1-F+F_current).*(1-P_b_Na));
        C_l_K2O=Bulk_Comp(10)./(D_K+F_current/(1-F+F_current).*(1-P_b_K));
        C_l_Al2O3=Bulk_Comp(3)./(D_Al+F_current/(1-F+F_current).*(1-P_b_Al));
        C_l_P2O5=Bulk_Comp(11)./(D_P+F_current/(1-F+F_current).*(1-P_b_P));
        C_l_TiO2=Bulk_Comp(2)./(D_Ti+F_current/(1-F+F_current).*(1-P_b_Ti));
        
        % Temperature of the melt, T_f1, first estimation
        T_c=[ones(size(F))'  ones(size(F))'.*P   MgN_liq'  C_l_Al2O3' C_l_Na2O'+C_l_K2O' C_l_P2O5'];
        T_f1=T_c*T_coeff;
        
        % calculte full melt composition (adding major elements) to calculate T_f2
        % The following regressions use minor incompatible elements, Mg# and P to
        % calculate major elements
        
        FeOMgO_c=[ones(size(F))' ones(size(F))'.*P ones(size(F))'.*P.^0.3 MgN_liq'  C_l_Al2O3' C_l_Na2O' C_l_K2O' C_l_P2O5'];
        SiO2CaO_c=[ones(size(F))' ones(size(F))'.*P ones(size(F))'.*P.^0.3 MgN_liq'  C_l_Al2O3' C_l_Na2O' C_l_K2O' C_l_P2O5' (C_l_Na2O'+C_l_K2O')./P C_l_P2O5'.*P];
        
        C_l_SiO2=SiO2CaO_c*SiO2_coeff;
        C_l_CaO=SiO2CaO_c*CaO_coeff;
        C_l_MgO=FeOMgO_c*MgO_coeff;
        
        % different ways of calculating C_l_FeO (see documentation)
        if KD(1) == 1
            C_l_FeO=FeOMgO_c*FeO_coeff; % based on FeO regression, but is then corrected to match initial Mg# liq
            MgN_liqC = (C_l_MgO/40.3045)./(C_l_MgO/40.3045 + C_l_FeO/71.8446)*100; % recalculated Mg# of melt
            while MgN_liqC > MgN_liq' % while new Mg# is too high, add FeO until match expected Mg#
                C_l_FeO = C_l_FeO+0.1;
                MgN_liqC = (C_l_MgO/40.3045)./(C_l_MgO/40.3045 + C_l_FeO/71.8446)*100; % recalculated Mg# of melt
            end
            while MgN_liqC < MgN_liq' % while new Mg# is too low, add MgO
                C_l_MgO = C_l_MgO +0.1;
                MgN_liqC = (C_l_MgO/40.3045)./(C_l_MgO/40.3045 + C_l_FeO/71.8446)*100; % recalculated Mg# of melt
            end
        end
        
        if KD(1) == 2
            C_l_FeO=C_l_MgO.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);  % based on MgO regression + KD, no corrections, KD not updated
        end
        
        if KD(1) == 3 % identical to mode 1 but more straight forward, calculate FeO so it matches the estimated Mg# liq
            C_l_FeO=(C_l_MgO.*(1-MgN_liq./100).*71.8464)./(40.3045.*MgN_liq./100);
        end
        
        if KD(1) == 4
            C_l_FeO=C_l_MgO.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);% based on FeO regression + KD, KD updated based on Toplis 2005
        end
        
        Cr2O3_c=[ones(size(F))' ones(size(F))'.*T_f1 ones(size(F))' C_l_Al2O3' C_l_Na2O'+C_l_K2O' C_l_P2O5'];
        C_l_Cr2O3=Cr2O3_c*Cr2O3_coeff;
        
        wf=[C_l_SiO2 C_l_Al2O3 C_l_FeO C_l_MgO C_l_CaO C_l_Na2O];
        wf=wf./sum(wf);
        
        % Simplification MnO derived from FeO content, assuming fixed Fe/Mn for
        % martian basalts
        C_l_MnO=wf(:,3)./38.7;
        
        % Add minor elements before normalizing (e.g. K2O, P2O)
        % CaO, Na2O can be added from wf or from original calculations...
        wf=[wf(:,1) C_l_TiO2'./100 C_l_Al2O3'./100 C_l_Cr2O3./100 wf(:,3) C_l_MnO wf(:,4:5) C_l_Na2O'./100  C_l_K2O'./100 C_l_P2O5'./100];
        % wf=[wf(:,1) C_l_TiO2'./100 wf(:,2) C_l_Cr2O3./100 wf(:,3) C_l_MnO wf(:,4) C_l_CaO'./100 C_l_Na2O'./100 C_l_K2O'./100 C_l_P2O5'./100];
        
        wf(wf<0)=0;
        wf=wf./sum(wf);
        wf=wf*100;
        %wf order 1_SiO2 2_TiO2 3_Al2O3 4_Cr2O4 5_FeO 6_MnO 7_MgO 8_CaO 9_Na2O
        %10_K2O 11_P2O5
        
        %update temperature...
        T_c=[ones(size(F))' ones(size(F))'.*P  MgN_liq' wf(3) wf(9)+wf(10) wf(11)];
        T_f2=T_c*T_coeff;
        
        % now use melt compostion, P and T to calculate actual KD with Toplis 2005, if mode 4 is activated
        if KD(1) == 4
            R_cst = 8.314;
            T_K = T_f2 + 273.15;
            P_bar = P * 10^4; %from GPa to bars
            MM_vec = [60.0843 79.8658 101.9613 151.9904 71.8464 70.9374 40.3045 56.0774 61.9789 94.196 141.9445];%vector of oxide molar masses
            
            %Mol (liq)
            mol_liq = wf./MM_vec;
            mol_pc = mol_liq./sum(mol_liq')'.*100;
            psy = (0.46*(100/(100-mol_pc(1)))-0.93) * (mol_pc(9)+mol_pc(10)) + (-5.33*(100/(100-mol_pc(1)))+9.69);
            SiO2_pc_A = mol_pc(1) + psy * (mol_pc(9)+mol_pc(10));
            
            KD_m = exp(((-6766/(R_cst*T_K))-(7.34/R_cst)) + log(0.036*SiO2_pc_A-0.22) + ((3000*(1-2*MgN_sol))/(R_cst*T_K)) + ((0.035*(P_bar-1))/(R_cst*T_K))); % KD modelled (Toplis 2005)
            
            % update KD first guess with new value
            KD(2) = KD_m;
            % use the corrected KD to calculate T and liquid composition...
            MgN_liq=1./((1./MgN_sol-1)/KD(2)+1)*100;
            
            FeOMgO_c=[ones(size(F))' ones(size(F))'.*P ones(size(F))'.*P.^0.3 MgN_liq'  C_l_Al2O3' C_l_Na2O' C_l_K2O' C_l_P2O5'];
            SiO2CaO_c=[ones(size(F))' ones(size(F))'.*P ones(size(F))'.*P.^0.3 MgN_liq'  C_l_Al2O3' C_l_Na2O' C_l_K2O' C_l_P2O5' (C_l_Na2O'+C_l_K2O')./P C_l_P2O5'.*P];
            
            C_l_SiO2=SiO2CaO_c*SiO2_coeff;
            C_l_CaO=SiO2CaO_c*CaO_coeff;
            C_l_MgO=FeOMgO_c*MgO_coeff;
            C_l_FeO=C_l_MgO.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);
            
            wf=[C_l_SiO2 C_l_Al2O3 C_l_FeO C_l_MgO C_l_CaO C_l_Na2O];
            wf=wf./sum(wf')';
            
            % Simplification MnO derived from FeO
            C_l_MnO=wf(:,3)./38.7;
            % Add minor elements before normalizing (e.g. K2O, P2O)
            % CaO, Na2O can be added from wf or from original calculations...
            wf=[wf(:,1) C_l_TiO2'./100 C_l_Al2O3'./100 C_l_Cr2O3./100 wf(:,3) C_l_MnO wf(:,4:5) C_l_Na2O'./100  C_l_K2O'./100 C_l_P2O5'./100];
            % wf=[wf(:,1) C_l_TiO2'./100 wf(:,2) C_l_Cr2O3./100 wf(:,3) C_l_MnO wf(:,4) C_l_CaO'./100 C_l_Na2O'./100 C_l_K2O'./100 C_l_P2O5'./100];
            
            wf(wf<0)=0;
            wf=wf./sum(wf)*100;
            %update temperature...
            T_c=[ones(size(F))' ones(size(F))'.*P  MgN_liq' wf(3) wf(9)+wf(10) wf(11)];
            T_f2=T_c*T_coeff;
        end
        
        if T >= T_f2 %mantle temperature higher than effective solidus
            %melting has started...
            
            % Liquid is partly removed from residue if CMF is exceeded, for lherz.
            % melting
            if (F_current > CMF) && (mode_eff(2)>0) % only if cpx is present
                Bulk_Comp=Bulk_Comp-wf*(F_current-CMF)/(1-F+(F_current-CMF));
                Bulk_Comp(Bulk_Comp<0)=0;
                Bulk_Comp=Bulk_Comp/sum(Bulk_Comp)*100;
                liq_ext=(liq_ext*((F-CMF)-F_inc)+wf*F_inc)/(F-CMF);
                mode_eff=mode_eff-Stoichio_Cf_eff*100*(F_current-CMF)/(1-F+(F_current-CMF)); % adjust mode
                mode_eff(mode_eff<0)=0; % if mode is negatif, make it 0
                mode_eff=mode_eff/sum(mode_eff)*100; % renormalized
                F=F+(F_current-CMF); % update melt fraction
                T=T-(F_current-CMF).*LH./Cp; % addjust T for latent heat
                F_current=CMF+F_inc; %update F_current for future melt evaluation
                
            elseif (F <= CMF) %melting has started but CMF is not reached..
                % don't change bulk composition or mode, just F
                if F<=F_inc
                    P_inters=[P_inters P]; % record the P at which melting begins
                end
                F=F+F_inc;
                F_current=F_current+F_inc;
                T=T-F_inc.*LH./Cp;
            end
        end        
        % Save P-T-F conditions
        P_rec=[P_rec; P];
        T_rec=[T_rec; T T_f1 T_f2]; % note that T_f2 is the effective solidus
        F_rec=[F_rec; F F_current]; %F, F_current
        
        % save mode, solid and liquid compositions
        mode_eff_rec=[mode_eff_rec; mode_eff]; %Opx, Cpx, Sp, Oliv
        sol_rec=[sol_rec; Bulk_Comp];% SiO2, TiO2, ... P2O5
        liq_inst_rec=[liq_inst_rec; wf];
        liq_ext_rec=[liq_ext_rec; liq_ext];
                
        % temperature adiabatic correction
        T=T-15*dP;
        
        % track modal composition, break loop if no more CPX
        [MODE_wt_sim, MODE_wt, Bulk_PX_Wo, OPX_frac] = MM_modecalc(Bulk_Comp);
        if MODE_wt_sim(2) <= 0
            break
        end
        if mode_eff(2)<0.1
            break
        end
    end
    
    %start new loop for harzburgite melting at P at which previous loop ended
    Stoichio_Cf_eff2=[0.76 0 0.06 0.18];
    Part_Coeff2=[Part_Coeff; 0.35 0 0 0.03];
    
    mode_eff(1)=mode_eff(1)+mode_eff(2); % move cpx not consumed to opx
    mode_eff2=[mode_eff(1) 0 mode_eff(3) mode_eff(4)]; % update starting mode, no cpx
    mode_eff2=mode_eff2./sum(mode_eff2)*100; % renormalize
    F2=F;
    T_f2b=NaN;
    
    %% LOOP2 -- Harzburgite melting
    for P2=P:-dP:End_P
        MgN_sol=(Bulk_Comp(7)./40.3045)/(Bulk_Comp(5)./70.8464+Bulk_Comp(7)./40.3045);
        MgN_liq=1./((1./MgN_sol-1)/KD(2)+1)*100;
        %% update partition coefficients based on pressure
        Part_Coeff2(1,1)=0.0091*P2^2+0.0054*P2+0.0168; %D Na opx-liq
        Part_Coeff2(1,2)=0.0158+0.0746*P2;   %D Na cpx-liq
        Part_Coeff2(3,1)=0.1614*P2+0.0849; %D Al opx-liq
        Part_Coeff2(3,2)=0.1877*P2+0.0932; %D Al cpx-liq
        if (P2>=1) && (P2<=2.5)
            Part_Coeff2(3,3)=1*P2^2-3.1*P2+3.2; %D Al Al-bearing phases
        elseif P2<1
            Part_Coeff2(3,3)=-4.8*P2+5.9;
        else
            Part_Coeff2(3,3)=1.72*P2-2.6;
        end
        Part_Coeff2(3,4)=0.0037*P2+0.0024; %D Al oliv-liq
        Part_Coeff2(5,2)=-0.0533*P2+0.2452-0.05; %D Ti cpx-liq
        
        % Bulk partition coefficents
        D_Na2=Part_Coeff2(1,:).*mode_eff2./100;D_Na2=sum(D_Na2);
        D_K2=Part_Coeff2(2,:).*mode_eff2./100;D_K2=sum(D_K2);
        D_Al2=Part_Coeff2(3,:).*mode_eff2./100;D_Al2=sum(D_Al2);
        D_P2=Part_Coeff2(4,:).*mode_eff2./100;D_P2=sum(D_P2);
        P_b_Na2=Part_Coeff2(1,:).*Stoichio_Cf_eff2;P_b_Na2=sum(P_b_Na2);
        P_b_K2=Part_Coeff2(2,:).*Stoichio_Cf_eff2;P_b_K2=sum(P_b_K2);
        P_b_Al2=Part_Coeff2(3,:).*Stoichio_Cf_eff2;P_b_Al2=sum(P_b_Al2);
        P_b_P2=Part_Coeff2(4,:).*Stoichio_Cf_eff2;P_b_P2=sum(P_b_P2);
        D_Ti2=Part_Coeff2(5,:).*mode_eff2./100;D_Ti2=sum(D_Ti2);
        P_b_Ti2=Part_Coeff2(5,:).*Stoichio_Cf_eff2;P_b_Ti2=sum(P_b_Ti2);
        D_Ca2=Part_Coeff2(7,:).*mode_eff2./100;D_Ca2=sum(D_Ca2);
        P_b_Ca2=Part_Coeff2(7,:).*Stoichio_Cf_eff2;P_b_Ca2=sum(P_b_Ca2);
        
        % Batch melting equations for harzburgite melting
        C_l_Na2O_2=Bulk_Comp(9)./(D_Na2+F_current/(1-F2+F_current).*(1-P_b_Na2));
        C_l_K2O_2=Bulk_Comp(10)./(D_K2+F_current/(1-F2+F_current).*(1-P_b_K2));
        C_l_Al2O3_2=Bulk_Comp(3)./(D_Al2+F_current/(1-F2+F_current).*(1-P_b_Al2));
        C_l_P2O5_2=Bulk_Comp(11)./(D_P2+F_current/(1-F2+F_current).*(1-P_b_P2));
        C_l_TiO2_2=Bulk_Comp(2)./(D_Ti2+F_current/(1-F2+F_current).*(1-P_b_Ti2));
        C_l_CaO_2=Bulk_Comp(8)./(D_Ca2+F_current/(1-F2+F_current).*(1-P_b_Ca2));
        
        T_c2=[ones(size(F2))' ones(size(F2))'.*P2  MgN_liq' C_l_Al2O3_2' C_l_Na2O_2'+C_l_K2O_2' C_l_P2O5_2'];
        T_f1b=T_c2*T_coeff2;
        
        % use T to adjust Ca Partition coeffients for harzburgite melting:
        % recalculate CaO concentration based on T_f
        % 4 columns (1_opx, 2_cpx, 3_spinel, 4_olivine)
        Part_Coeff2_DCa=NaN*ones(size(T_f1b,1),4);
        Part_Coeff2_DCa(:,1)=1.0471+0.05648.*ones(size(F2))'.*P2-0.0006045.*T_f1b;
        Part_Coeff2_DCa(:,2)=0;Part_Coeff2_DCa(:,3)=0;
        Part_Coeff2_DCa(:,4)=0.1-2e-5.*T_f1b;
        Bulk_DCa2=sum((Part_Coeff2_DCa.*mode_eff2./100)')';
        P_b_Ca2=Part_Coeff2_DCa.*Stoichio_Cf_eff2;P_b_Ca2=sum(P_b_Ca2')';
        C_l_CaO_2=Bulk_Comp(8)./(Bulk_DCa2+(F_current/(1-F2+F_current))'.*(1-P_b_Ca2));C_l_CaO_2=C_l_CaO_2';
        
        % use incompatlbe minor elements, Mg# and P to calculate the concentrations of major elements
        FeOMgO_c2=[ones(size(F2))' ones(size(F2))'.*P2 ones(size(F2))'.*P2.^0.3 MgN_liq'  C_l_Al2O3_2' C_l_Na2O_2' C_l_K2O_2' C_l_P2O5_2'];
        SiO2CaO_c2=[ones(size(F2))' ones(size(F2))'.*P2 ones(size(F2))'.*P2.^0.3 MgN_liq'  C_l_Al2O3_2' C_l_Na2O_2' C_l_K2O_2' C_l_P2O5_2' (C_l_Na2O_2'+C_l_K2O_2')./P2 C_l_P2O5_2'.*P2];
        C_l_MgO_2=FeOMgO_c2*MgO_coeff2;
        
        if KD(1) == 1 % see anotations in previous loop
            C_l_FeO_2 = FeOMgO_c2*FeO_coeff2;
            MgN_liqC = (C_l_MgO_2/40.3045)./(C_l_MgO_2/40.3045 + C_l_FeO_2/71.8446)*100;
            while MgN_liqC > MgN_liq'
                C_l_FeO_2 = C_l_FeO_2+0.1;
                MgN_liqC = (C_l_MgO_2/40.3045)./(C_l_MgO_2/40.3045 + C_l_FeO_2/71.8446)*100;
            end
            while MgN_liqC < MgN_liq'
                C_l_MgO_2 = C_l_MgO_2+0.1;
                MgN_liqC = (C_l_MgO_2/40.3045)./(C_l_MgO_2/40.3045 + C_l_FeO_2/71.8446)*100;
            end
        end
        
        if KD(1) == 2
            C_l_FeO_2=C_l_MgO_2.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);
        end
        
        if KD(1) == 3
            C_l_FeO_2=(C_l_MgO_2.*(1-MgN_liq./100).*71.8464)./(40.3045.*MgN_liq./100);
        end
        
        if KD(1) == 4
            C_l_FeO_2=C_l_MgO_2.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);
        end
        
        C_l_SiO2_2=SiO2CaO_c2*SiO2_coeff2;
        
        Cr2O3_c2=[ones(size(F2))' ones(size(F2))'.*T_f1b ones(size(F2))' C_l_Al2O3_2' C_l_Na2O_2'+C_l_K2O_2' C_l_P2O5_2'];
        C_l_Cr2O3_2=Cr2O3_c2*Cr2O3_coeff2;
        
        
        wf2=[C_l_SiO2_2 C_l_Al2O3_2 C_l_FeO_2 C_l_MgO_2 C_l_CaO_2 C_l_Na2O_2];
        wf2=wf2./sum(wf2')';
        
        C_l_MnO_2=wf2(:,3)./38.7;
        %add minor elements before normalizing, K2O, P2O
        wf2=[wf2(:,1) C_l_TiO2_2'./100 C_l_Al2O3_2'./100 C_l_Cr2O3_2./100 wf2(:,3) C_l_MnO_2 wf2(:,4) C_l_CaO_2'./100 C_l_Na2O_2'./100 C_l_K2O_2'./100 C_l_P2O5_2'./100];
        wf2=wf2./sum(wf2')';
        wf2=wf2*100;
        %wf order 1_SiO2 2_TiO2 3_Al2O3 4_Cr2O4 5_FeO 6_MnO 7_MgO 8_CaO 9_Na2O
        %10_K2O 11_P2O5
        
        %update temperature
        T_c2=[ones(size(F2))' ones(size(F2))'.*P2  MgN_liq' wf2(3) wf2(9)+wf2(10) wf2(11)];
        T_f2b=T_c2*T_coeff2;
        
        % now use melt compostion, P and T to calculate actual KD with Toplis 2005
        if KD(1) == 4
            R_cst = 8.314;
            T_K = T_f2 + 273.15;
            P_bar = P2 * 10^4; %from GPa to bars
            
            %Mol (liq)
            mol_liq = wf2./MM_vec;
            mol_pc = mol_liq./sum(mol_liq')'.*100;
            psy = (0.46*(100/(100-mol_pc(1)))-0.93) * (mol_pc(9)+mol_pc(10)) + (-5.33*(100/(100-mol_pc(1)))+9.69);
            SiO2_pc_A = mol_pc(1) + psy * (mol_pc(9)+mol_pc(10));
            
            KD_m = exp(((-6766/(R_cst*T_K))-(7.34/R_cst)) + log(0.036*SiO2_pc_A-0.22) + ((3000*(1-2*MgN_sol))/(R_cst*T_K)) + ((0.035*(P_bar-1))/(R_cst*T_K))); % KD modelled (Toplis 2005)
            
            % update KD first guess with new value
            KD(2) = KD_m;
            % use the corrected KD to calculate T and liquid composition...
            MgN_liq=1./((1./MgN_sol-1)/KD(2)+1)*100;
            
            FeOMgO_c2=[ones(size(F2))' ones(size(F2))'.*P2 ones(size(F2))'.*P2.^0.3 MgN_liq'  C_l_Al2O3_2' C_l_Na2O_2' C_l_K2O_2' C_l_P2O5_2'];
            SiO2CaO_c2=[ones(size(F2))' ones(size(F2))'.*P2 ones(size(F2))'.*P2.^0.3 MgN_liq'  C_l_Al2O3_2' C_l_Na2O_2' C_l_K2O_2' C_l_P2O5_2' (C_l_Na2O_2'+C_l_K2O_2')./P2 C_l_P2O5_2'.*P2];
            
            C_l_SiO2_2=SiO2CaO_c2*SiO2_coeff2;
            C_l_MgO_2=FeOMgO_c2*MgO_coeff2;
            C_l_FeO_2=C_l_MgO_2.*(Bulk_Comp(5)./Bulk_Comp(7))./KD(2);
            
            wf2=[C_l_SiO2_2 C_l_Al2O3_2 C_l_FeO_2 C_l_MgO_2 C_l_CaO_2 C_l_Na2O_2];
            wf2=wf2./sum(wf2')';
            % Simplification MnO derived from FeO content...
            C_l_MnO_2=wf2(:,3)./38.7;
            % Add minor elements before normalizing (e.g. K2O, P2O)
            % CaO, Na2O can be added from wf or from original calculations...
            wf2=[wf2(:,1) C_l_TiO2_2'./100 C_l_Al2O3_2'./100 C_l_Cr2O3_2./100 wf2(:,3) C_l_MnO_2 wf2(:,4:5) C_l_Na2O_2'./100  C_l_K2O_2'./100 C_l_P2O5_2'./100];
            
            wf2(wf2<0)=0;
            wf2=wf2./sum(wf2)*100;
            %update temperature...
            T_c2=[ones(size(F2))' ones(size(F2))'.*P2  MgN_liq' wf2(3) wf2(9)+wf2(10) wf2(11)];
            T_f2b = T_c2*T_coeff2;
            %T_f2b = 815.3 + 39.16*P2 + 2.655*MgN_liq + 6.646*(wf2(9)+wf2(10)) + 8.61*wf2(5) + 15.37*wf2(7);
            
        end
        % test whether melting has actually began,
        % meaning, if T > T_f2
        
        if (T >= T_f2b) && (F_current > CMF)
            Bulk_Comp=Bulk_Comp-wf2*(F_current-CMF)/(1-F2+(F_current-CMF));
            Bulk_Comp(Bulk_Comp<0)=0;
            Bulk_Comp=Bulk_Comp/sum(Bulk_Comp)*100;
            liq_ext=(liq_ext*((F2-CMF)-F_inc)+wf2*F_inc)/(F2-CMF);
            mode_eff2=mode_eff2-Stoichio_Cf_eff2*100*(F_current-CMF)/(1-F2+(F_current-CMF)); % adjust mode
            mode_eff2(mode_eff2<0)=0; % if mode is negatif, make it 0
            mode_eff2=mode_eff2/sum(mode_eff2)*100; % renormalized
            F2=F2+(F_current-CMF);%update melt fraction
            
            T=T-(F_current-CMF).*LH./Cp; % correct T for latent heat
            F_current=CMF+F_inc;%for future melt evaluation
        elseif (T >= T_f2b) && (F2 <= CMF) %melting has started but CMF is not reached..
            % don't change bulk or mode, just F
            if F2<=F_inc
            P_inters=[P_inters P2]; %save pressure at which the effective solidus is reached
            end
            F2=F2+F_inc;
            F_current=F_current+F_inc;
            T=T-F_inc.*LH./Cp;
        end                
        % save P-T-F conditions, mode, liquid, solid compositions
        P_rec=[P_rec; P2];
        T_rec=[T_rec; T T_f1b T_f2b]; %T, T_f1, T_f2
        F_rec=[F_rec; F2 F_current]; %F, F_current
        mode_eff_rec=[mode_eff_rec; mode_eff2]; %Opx, Cpx, Sp, Oliv
        sol_rec=[sol_rec; Bulk_Comp];% SiO2, TiO2, ... P2O5
        liq_inst_rec=[liq_inst_rec; wf2];
        liq_ext_rec=[liq_ext_rec; liq_ext];
                
        T=T-15*dP; %correct T for adiab. decompression
        
        % approx mode and break loop if no more opx
        [MODE_wt_sim, MODE_wt, Bulk_PX_Wo, OPX_frac] = MM_modecalc(Bulk_Comp);
        if MODE_wt_sim(1) <= 0
            break
        end
    end
    F3=F2;
    % LOOP3 -- dunite melting (rarely necessary... requires extreme temperatures)
    for P3=P2:-dP:End_P
        MgN_sol=(Bulk_Comp(7)./40.3045)/(Bulk_Comp(5)./70.8464+Bulk_Comp(7)./40.3045);
        MgN_liq=1./((1./MgN_sol-1)/KD(2)+1)*100;
        
        T_c2=[ones(size(F3))' ones(size(F3))'.*P3 MgN_liq' 0.00 0.00 0.00];
        % assuming the melt is made of pure olivine
        wf3 = [MM_vec(1) 0 0 0.5 MM_vec(5)*(100-MgN_liq)/100*2 0 MM_vec(7)*MgN_liq/100*2 0 0 0 0];
        wf3(6)=wf3(5)./38.7; % addjust MnO to match FeO/MnO of ~40...
        wf3=wf3./sum(wf3)*100;
        
        % update temperature using Putirka et 2008 (equation 8)
        T_f2b = 815.3 + 39.16*P3 + 2.655*MgN_liq + 6.646*(wf3(9)+wf3(10)) + 8.61*wf3(5) + 15.37*wf3(7);
        %T_f2b = T_c2*T_coeff2;
        
        if (T >= T_f2b) && (F_current > CMF)
            Bulk_Comp=Bulk_Comp-wf3*(F_current-CMF)/(1-F3+(F_current-CMF));
            Bulk_Comp(Bulk_Comp<0)=0;
            Bulk_Comp=Bulk_Comp/sum(Bulk_Comp)*100;
            liq_ext=(liq_ext*((F3-CMF)-F_inc)+wf3*F_inc)/(F3-CMF);
            F3=F3+(F_current-CMF);%update melt fraction
            
            T=T-(F_current-CMF).*LH./Cp;
            F_current=CMF+F_inc;%for future melt evaluation
        elseif (T >= T_f2b) && (F3 <= CMF) %melting has started but CMF is not reached..
            % don't change bulk or mode, just F
            if F3<=F_inc
            P_inters=[P_inters P3];
            end
            F3=F3+F_inc;
            F_current=F_current+F_inc;
            T=T-F_inc.*LH./Cp;
        end
           
        [MODE_wt_sim, MODE_wt, Bulk_PX_Wo, OPX_frac] = MM_modecalc(Bulk_Comp);
        % save P-T-F conditions, mode, solid and liquid compositions
        P_rec=[P_rec; P3];
        T_rec=[T_rec; T T_f2b T_f2b]; %T, T_f1, T_f2
        F_rec=[F_rec; F3 F_current]; %F, F_current
        mode_eff_rec=[mode_eff_rec; MODE_wt_sim]; %Opx, Cpx, Sp, Oliv
        sol_rec=[sol_rec; Bulk_Comp];% SiO2, TiO2, ... P2O5
        liq_inst_rec=[liq_inst_rec; wf3];
        liq_ext_rec=[liq_ext_rec; liq_ext];        
        
        T=T-15*dP;
        
        % let's not melt more than 100%!
        if F3 > 1
            break
        end
    end
    
    % remove initial NaN and save all in a structure
    F_rec = F_rec(2:end,:); detail_comp(jj).F_rec = F_rec;
    ind = find(F_rec(:,1)>0.001); F_rec2 = F_rec(ind,:);
    detail_comp2(jj).F_rec2 = F_rec2;
    
    P_rec = P_rec(2:end); detail_comp(jj).P_rec = P_rec;
    P_rec2 = P_rec(ind); detail_comp2(jj).P_rec2 = P_rec2;
    if ~isempty(P_rec2)
        P_inters2 = [P_inters2; P_rec2(1)];
    end
    T_rec = T_rec(2:end,:); detail_comp(jj).T_rec = T_rec;
    T_rec2 = T_rec(ind,:);  detail_comp2(jj).T_rec2 = T_rec2;
    
    mode_eff_rec = mode_eff_rec(2:end,:); detail_comp(jj).mode_eff_rec = mode_eff_rec;
    mode_eff_rec2 = mode_eff_rec(ind,:); detail_comp2(jj).mode_eff_rec2 = mode_eff_rec2;
    
    sol_rec = sol_rec(2:end,:); detail_comp(jj).sol_rec = sol_rec;
    sol_rec2 = sol_rec(ind,:); detail_comp2(jj).sol_rec2 = sol_rec2;
    
    liq_inst_rec = liq_inst_rec(2:end,:); detail_comp(jj).liq_inst_rec = liq_inst_rec;
    liq_inst_rec2 = liq_inst_rec(ind,:); detail_comp2(jj).liq_inst_rec2 = liq_inst_rec2;
    
    liq_ext_rec = liq_ext_rec(2:end,:); detail_comp(jj).liq_ext_rec = liq_ext_rec;
    liq_ext_rec2 = liq_ext_rec(ind,:); detail_comp2(jj).liq_ext_rec2 = liq_ext_rec2;
    
    plot_adiab=[T_start, Tp_Mantle; Start_P, 0];
    
    if plotit == 1
        figure(9)
        plot(T_rec(:,1),P_rec,'-b')
        ylim([0 5])
        xlim([1100 1700])
        hold on
        plot(T_rec(:,1),P_rec,'-m','LineWidth',1)
        plot(plot_adiab(1,:),plot_adiab(2,:),'k')
        plot(T_rec(:,3),P_rec,'-b')
        
        if Iso_mode == 1
            scatter(T_rec2(:,3),P_rec2,20,F_rec2(:,1),'fill')
        else
            scatter(T_rec2(:,1),P_rec2,20,F_rec2(:,1),'fill')
        end
        set(get(colorbar,'Title'),'String','     Melt F')
        set(gca,'FontSize',12)
        xlabel('temperature (�C)')
        ylabel('pressure (GPa)')
        colormap jet
        set(gca,'XAxisLocation','top','YAxisLocation','left','ydir','reverse');
        set(gca,'TickLength',[0.02 0.035])
        set(gca,'LineWidth',1);
        caxis([0 0.3])
        xxx=0:0.2:5; 
        yyy=-6.1.*xxx.^2+145.*xxx+1045.66; % parametrized solidus from Collinet et al. 2015
        plot(yyy,xxx,'--m')
        box on
        set(gcf,'Renderer', 'painters', 'Position', [0 0 600 400])
    end
    
    if F3>F2+0.001
        F_terminal=[F_terminal;F3 3];
    elseif F2>F+0.001
        F_terminal=[F_terminal;F2 2];
    else
        F_terminal=[F_terminal;F 1];
    end
    liq_ext_term=[liq_ext_term; liq_ext];
    T_terminal=[T_terminal; T];
    res_mantle = [res_mantle; Bulk_Comp];
    
    if Iso_mode == 1
        Start_P = End_P;
    end
    jj = jj+1; %increment index for saving structure
end
P_inters = P_inters(2:end);P_inters2 = P_inters2(2:end);
T_terminal = T_terminal(2:end); T_terminal = T_terminal(size(T_terminal,1)-size(P_inters2,1)+1:end);
liq_ext_term = liq_ext_term(2:end,:); liq_ext_term = liq_ext_term(size(liq_ext_term,1)-size(P_inters2,1)+1:end,:);
res_mantle = res_mantle(2:end,:); res_mantle = res_mantle(size(res_mantle,1)-size(P_inters2,1)+1:end,:);
F_terminal = F_terminal(2:end,:); F_terminal = F_terminal(size(F_terminal,1)-size(P_inters2,1)+1:end,:);
Tp_Mantle=[Tp_min:Tp_inc:Tp_max]'; Tp_Mantle = Tp_Mantle(size(Tp_Mantle,1)-size(P_inters2,1)+1:end,:);

% calculate equivalent batch T
Tb = NaN*ones(size(P_inters2,1),1);
MgN_term = (liq_ext_term(:,7)./40.3045)./(liq_ext_term(:,7)./40.3045+liq_ext_term(:,5)./71.8446)*100;
Average_P = (P_inters+End_P*ones(size(P_inters,1),1))/2;
 
ind_lherz=find(F_terminal(:,2)==1);
ind_harz=find(F_terminal(:,2)==2);
ind_dunite=find(F_terminal(:,2)==3);
if ~isempty(ind_lherz)
    Tb_lherz_i=[ones(size(ind_lherz)) ones(size(ind_lherz)).*Average_P(ind_lherz)'  MgN_term(ind_lherz) liq_ext_term(ind_lherz,3) liq_ext_term(ind_lherz,9)+liq_ext_term(ind_lherz,10) liq_ext_term(ind_lherz,11)];
    Tb(ind_lherz)=Tb_lherz_i*T_coeff;
end
if ~isempty(ind_harz)
    Tb_harz_i=[ones(size(ind_harz)) ones(size(ind_harz)).*Average_P(ind_harz)'  MgN_term(ind_harz) liq_ext_term(ind_harz,3) liq_ext_term(ind_harz,9)+liq_ext_term(ind_harz,10) liq_ext_term(ind_harz,11)];
    Tb(ind_harz)=Tb_harz_i*T_coeff2;
end
if ~isempty(ind_dunite)
    Tb(ind_dunite) = 815.3 + 39.16*Average_P(ind_dunite)' + 2.655*MgN_term(ind_dunite) + 6.646*(liq_ext_term(ind_dunite,9)+liq_ext_term(ind_dunite,10)) + 8.61*liq_ext_term(ind_dunite,5) +  15.37*liq_ext_term(ind_dunite,7);
end
    
Tp_b = Tb - Adiab*Average_P' + F_terminal(:,1).*LH./Cp; %calculate equivalent batch Tp

Final_table.data=[Tp_Mantle Tp_b Tb liq_ext_term F_terminal(:,1)*100 P_inters2];
Final_residue.data=[Tp_Mantle T_terminal res_mantle F_terminal(:,1)*100 F_terminal(:,2) P_inters2];

Final_table.labelsForm = '%8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s\n';
Final_table.dataForm = '%8.0f %8.0f %8.0f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.3f %8.2f %8.2f %8.1f %8.1f\n';
Final_residue.labelsForm = '%8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s %8s\n';
Final_residue.dataForm = '%8.0f %8.0f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.3f %8.2f %8.1f %8.0f %8.1f\n';

fileID = fopen([name 'AggrMelt' '.txt'],'w');
fprintf(fileID,Final_table.labelsForm,'Tp','Tp_batch','T_batch','SiO2','TiO2','Al2O3','Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','F','P_start');
fprintf(fileID,Final_table.dataForm,Final_table.data');
fclose(fileID);

fileID = fopen([name 'ResMantle' '.txt'],'w');
fprintf(fileID,Final_residue.labelsForm,'Tp','Tmantle','SiO2','TiO2','Al2O3','Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','F','ResType','P_start');
fprintf(fileID,Final_residue.dataForm,Final_residue.data');
fclose(fileID);
end