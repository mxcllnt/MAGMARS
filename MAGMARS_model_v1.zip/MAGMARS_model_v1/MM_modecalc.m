function [MODE_wt_sim, MODE_wt, Bulk_PX_Wo, OPX_frac] = MM_modecalc(Bulk_mantle)
% approx. mode composition based on mantle composition in wt.%

Bulk_mantle = Bulk_mantle./sum(Bulk_mantle')'.*100;

MMCat = [60.084 79.878 50.981 75.995 71.8464 70.937 40.3045 56.079 30.990 47.098 70.972];
MM = MMCat.*[1 1 2 2 1 1 1 1 2 2 2];

Bulk_mole = Bulk_mantle./MM;
Bulk_mole = Bulk_mole./sum(Bulk_mole')'.*100;

Chromite = Bulk_mole(4)*2;
MM_Chromite = 223.83;
Bulk_mole(5) = Bulk_mole(5) - Bulk_mole(4);
Bulk_Chromite = [0 0 0 Bulk_mole(4) Bulk_mole(4) 0 0 0 0 0 0];
Bulk_mole(4) = 0;

MgN = Bulk_mole(7)./(Bulk_mole(7)+Bulk_mole(5));

Jadeite = Bulk_mole(9)*6;
MM_Jadeite = 202.14;
Bulk_mole(3) = Bulk_mole(3)-Bulk_mole(9);
Bulk_mole(1) = Bulk_mole(1)-Bulk_mole(9)*4;
Bulk_Jadeite = [Bulk_mole(9)*4 0 Bulk_mole(9) 0 0 0 0 0 Bulk_mole(9) 0 0];
Bulk_mole(9) = 0;

CATS = Bulk_mole(3)*3;
MM_CATS = 218.12;
Bulk_mole(8) = Bulk_mole(8)-Bulk_mole(3);
Bulk_mole(1) = Bulk_mole(1)-Bulk_mole(3);
Bulk_CATS = [Bulk_mole(3) 0 Bulk_mole(3) 0 0 0 0 Bulk_mole(3) 0 0 0];
Bulk_mole(3) = 0;

CPX = Bulk_mole(8)*4;
MM_CPX = 56.08 + 71.8446*(1-MgN) + 40.3045*MgN + 2*60.08;
Bulk_mole(7) = Bulk_mole(7) - Bulk_mole(8)*MgN;
Bulk_mole(5) = Bulk_mole(5) - Bulk_mole(8)*(1-MgN);
Bulk_mole(1) = Bulk_mole(1) - Bulk_mole(8)*2;
Bulk_CPX = [Bulk_mole(8)*2 0 0 0 Bulk_mole(8)*(1-MgN) 0 Bulk_mole(8)*MgN Bulk_mole(8) 0 0 0];
Bulk_mole(8) = 0;

OPX_frac = ((Bulk_mole(1)./(Bulk_mole(5)+Bulk_mole(7)))-0.5)./0.5;
OPX = sum(Bulk_mole')'*OPX_frac;
MM_OPX = 71.8446*(1-MgN)*2 + 40.3045*MgN*2 + 2*60.08;
Bulk_OPX = [OPX/2 0 0 0 OPX/2*(1-MgN) 0 OPX/2*MgN 0 0 0 0];

OLIV = sum(Bulk_mole')'*(1-OPX_frac);
MM_OLIV = 71.8446*(1-MgN)*2 + 40.3045*MgN*2 + 60.08;
Bulk_OLIV = [OPX/3 0 0 0 OPX/3*2*(1-MgN) 0 OPX/3*2*MgN 0 0 0 0];

Bulk_PX = Bulk_OPX + Bulk_CPX + Bulk_CATS + Bulk_Jadeite;
Bulk_PX_Wo = Bulk_PX(8)./(Bulk_PX(8)+Bulk_PX(7)+Bulk_PX(5))*100; 
Bulk_PX_wt = Bulk_PX.*MM/sum((Bulk_PX.*MM)')'*100;

MODE_mol = [Chromite Jadeite CATS CPX OPX OLIV];
MODE_wt = MODE_mol.*[MM_Chromite MM_Jadeite MM_CATS MM_CPX MM_OPX MM_OLIV];
MODE_wt = MODE_wt./sum(MODE_wt')'.*100;

MODE_wt_sim = [MODE_wt(5) MODE_wt(2)+MODE_wt(3)+MODE_wt(4) MODE_wt(1) MODE_wt(6)];
if Bulk_PX_Wo < 7
    MODE_wt_sim = [MODE_wt(5)+MODE_wt(2)+MODE_wt(3)+MODE_wt(4) 0 MODE_wt(1) MODE_wt(6)];
    % attribute all px to opx
end
if OPX_frac < 0.001
    MODE_wt_sim = [0 0 MODE_wt(1) MODE_wt(6)];
    % no more pyroxene
end
MODE_wt_sim = MODE_wt_sim./sum(MODE_wt_sim')'.*100; %normalize
end

