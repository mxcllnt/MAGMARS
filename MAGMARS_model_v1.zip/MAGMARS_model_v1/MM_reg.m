function [SiO2_coeff,SiO2_coeff2,CaO_coeff,CaO_coeff2,FeO_coeff,FeO_coeff2,MgO_coeff,MgO_coeff2,Cr2O3_coeff,Cr2O3_coeff2,T_coeff,T_coeff2] = MM_reg(T_continuous)
%extract regression coefficients to be used in melting model...

%% regression for lherzolite melting 
DWExt=load('lherzolite_reg.txt');
[DWExt] = WeighObs(DWExt); % dublicate observations based on assigned weight
dlmwrite('lherzolite_reg2.txt',DWExt,'\t')

P=DWExt(:,2);
T=DWExt(:,3);

%normalize
DWExt(:,4:14) = DWExt(:,4:14) ./ sum(DWExt(:,4:14)')' * 100;

SiO2=DWExt(:,4);TiO2=DWExt(:,5);Al2O3=DWExt(:,6);Cr2O3=DWExt(:,7);
FeO=DWExt(:,8);MnO=DWExt(:,9);MgO=DWExt(:,10);CaO=DWExt(:,11);
Na2O=DWExt(:,12);K2O=DWExt(:,13);P2O5=DWExt(:,14);

MgN = (DWExt(:,10)./40.3045) ./ (DWExt(:,10)./40.3045 + DWExt(:,8)./70.8446) .* 100;

T_r1=[T];
% use predicator variable from code v20 for T
PredVar_1=[ones(size(DWExt,1),1) P MgN Al2O3 Na2O+K2O P2O5];

T_r1_coeff=PredVar_1\T_r1;
T_r1_recalc=PredVar_1*T_r1_coeff;

T_coeff=T_r1_coeff; %save coefficents for Temperature

MgO_r1=MgO; FeO_r1=FeO;
% use predicator variable from code v16 for FeO and MgO
PredVar_1=[ones(size(DWExt,1),1) P P.^0.3 MgN Al2O3 Na2O K2O P2O5];

FeO_r1_coeff=PredVar_1\FeO_r1;
FeO_r1_recalc=PredVar_1*FeO_r1_coeff;

MgO_r1_coeff=PredVar_1\MgO_r1;
MgO_r1_recalc=PredVar_1*MgO_r1_coeff;

%save regression coefficients for FeO and MgO 
FeO_coeff=FeO_r1_coeff;
MgO_coeff=MgO_r1_coeff;

SiO2_r1=SiO2; CaO_r1=CaO;
% use predicator variable from code v17 for SiO2 and CaO
PredVar_1=[ones(size(DWExt,1),1) P P.^0.3 MgN Al2O3 Na2O K2O P2O5 (Na2O+K2O)./P P2O5.*P];

SiO2_r1_coeff=PredVar_1\SiO2_r1;
SiO2_r1_recalc=PredVar_1*SiO2_r1_coeff;

CaO_r1_coeff=PredVar_1\CaO_r1;
CaO_r1_recalc=PredVar_1*CaO_r1_coeff;

%save regression coefficients for SiO2 and CaO 
SiO2_coeff=SiO2_r1_coeff;
CaO_coeff=CaO_r1_coeff;

Cr2O3_r1=Cr2O3;
% use predicator variable from code v27 for Cr2O3
PredVar_1=[ones(size(DWExt,1),1) T P Al2O3 Na2O+K2O P2O5];
Cr2O3_r1_coeff=PredVar_1\Cr2O3_r1;
Cr2O3_r1_recalc=PredVar_1*Cr2O3_r1_coeff;

%save regression coefficients for Cr2O3
Cr2O3_coeff=Cr2O3_r1_coeff;

%% regression for harzburgite melting -
format long
DWExt=load('harzburgite_reg.txt');
[DWExt] = WeighObs(DWExt); % dublicate observations based on weight
dlmwrite('harzburgite_reg2.txt',DWExt,'\t')

P=DWExt(:,2);
T=DWExt(:,3);
SiO2=DWExt(:,4);TiO2=DWExt(:,5);Al2O3=DWExt(:,6);Cr2O3=DWExt(:,7);
FeO=DWExt(:,8);MnO=DWExt(:,9);MgO=DWExt(:,10);CaO=DWExt(:,11);
Na2O=DWExt(:,12);K2O=DWExt(:,13);P2O5=DWExt(:,14);

MgN = (DWExt(:,10)./40.3045) ./ (DWExt(:,10)./40.3045 + DWExt(:,8)./70.8446) .* 100;
T_r1=[T];

PredVar_1=[ones(size(DWExt,1),1) P MgN Al2O3 Na2O+K2O P2O5];
T_r1_coeff=PredVar_1\T_r1;
T_r1_recalc=PredVar_1*T_r1_coeff;

T_coeff2=T_r1_coeff; %save coefficents for Temperature

MgO_r1=MgO; FeO_r1=FeO;

% use predicator variable from code v16 for FeO and MgO
PredVar_1=[ones(size(DWExt,1),1) P P.^0.3 MgN Al2O3 Na2O K2O P2O5];

FeO_r1_coeff=PredVar_1\FeO_r1;
FeO_r1_recalc=PredVar_1*FeO_r1_coeff;

MgO_r1_coeff=PredVar_1\MgO_r1;
MgO_r1_recalc=PredVar_1*MgO_r1_coeff;

%save regression coefficients for FeO and MgO 
FeO_coeff2=FeO_r1_coeff;
MgO_coeff2=MgO_r1_coeff;

SiO2_r1=SiO2; CaO_r1=CaO;

PredVar_1=[ones(size(DWExt,1),1) P P.^0.3 MgN Al2O3 Na2O K2O P2O5 (Na2O+K2O)./P P2O5.*P];
SiO2_r1_coeff=PredVar_1\SiO2_r1;
SiO2_r1_recalc=PredVar_1*SiO2_r1_coeff;

CaO_r1_coeff=PredVar_1\CaO_r1;
CaO_r1_recalc=PredVar_1*CaO_r1_coeff;

%save regression coefficients for SiO2 and CaO 
SiO2_coeff2=SiO2_r1_coeff;
CaO_coeff2=CaO_r1_coeff;

Cr2O3_r1=Cr2O3;
% use predicator variable from code v27 for Cr2O3
PredVar_1=[ones(size(DWExt,1),1) T P Al2O3 Na2O+K2O P2O5];
Cr2O3_r1_coeff=PredVar_1\Cr2O3_r1;
Cr2O3_r1_recalc=PredVar_1*Cr2O3_r1_coeff;

%save regression coefficients for Cr2O3
Cr2O3_coeff2=Cr2O3_r1_coeff;

%% VARIANT T1=T2
if T_continuous(1) == 1
T_coeff=T_coeff2;
end
if T_continuous(1) == 2
T_coeff2=T_coeff;
end   

