function [NewData] = WeighObs(OldData)
%WeighObs
%   use a matrix containing observations (as lines) and multiply the
%   observations by their weight (the first column) to create new matrix
%   with duplicate observations. 
Weight=OldData(:,1);
Weight=Weight./min(Weight);
Weight=round(Weight);
NewData=NaN*ones(1,size(OldData,2));
for ii=1:size(Weight,1)
MultiObs=ones(Weight(ii),size(OldData,2)).*OldData(ii,:);
NewData=[NewData; MultiObs];
end
NewData=NewData(2:size(NewData,1),:);
end

