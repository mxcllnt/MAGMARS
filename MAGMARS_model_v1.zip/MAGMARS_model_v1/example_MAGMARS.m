tic
Bulk_CompAP = [44.4442    0.1331    3.1688    0.7808   17.5174    0.4705   30.3301    2.4400    0.5106    0.0411    0.1635]; %Adk prim
[Final_tableAP,Final_residueAP,detail_compAP,detail_comp2_AP] = MAGMARS_v1('AP',5,1,Bulk_CompAP,0.004,1420,0,1420,0,[4, 0.35],[0 1300],1);

Bulk_CompAD = [44.1621    0.0701    2.5604    0.7993   17.3175    0.4696   32.8131    1.5024    0.2502    0.0055    0.0500]; %Adk depl
[Final_tableAD,Final_residueAD,detail_compAD,detail_comp2_AD] = MAGMARS_v1('AD',5,1.8,Bulk_CompAD,0.004,1390,0,1390,0,[4, 0.35],[0 2000],1);
 
Bulk_Comp81=[45.5	0.07	2.8764879	0.855548088	14.6	0.405567348	33.7	1.50250553	0.3	0.008	0.06]; %Adk depl and Mg
[Final_table81,Final_residue81,detail_comp81,detail_comp2_81] = MAGMARS_v1('81',5,2.25,Bulk_Comp81,0.004,1475,0,1475,0,[4, 0.35],[0 2000],1);
toc    