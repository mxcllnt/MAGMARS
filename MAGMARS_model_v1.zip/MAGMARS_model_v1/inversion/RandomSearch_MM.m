clear all
tic
rng('shuffle') % schuffle seed for "true" randomness
Folder = cd;
Folder = fullfile(Folder, '..');
addpath(Folder)
%% Set variables here

% polybaric melting variables
Start_P = 5; 
End_P_ini = 1.8; 
End_P_range = 0.3; % range on End_P_ini 
Tp_poly=[1350,10,1450]; %(Min, Increment, Max)

% isobaric melting variables
Start_P_iso = 2.0; 
P_iso_range = 0.4;
Tp_iso=[1370,10,1490]; %(Min, Increment, Max) is also hotter than Tp_poly

% general variables
Bulk_ini=[44.15	0.07	2.5	0.85	17.30	0.46	30.8	1.54	0.22	0.005	0.05];
simulN= 251; %number of simulations 
Bulk_range0 = 0.11; Bulk_range1 = 0.13; Bulk_range2 = 0.30; %for changing bulk composition randomly 

% PICK A NAME TO AVOID OVERWRITTING PREVIOUS CALCULATIONS
FName_iso='AdK_depl_iso.mat';
FName_poly='AdK_depl_poly.mat';

%% polybaric melting
KD = [4 0.35]; 
T_continuous = [0 1300];
plotit = 0; %0=false don't plot figure 9
Tp_profile=Tp_poly(1):Tp_poly(2):Tp_poly(3);
Tp_profile=[NaN Tp_profile];
Iso_mode = 0; % 0 - polybaric

for i=1:simulN
% vary End_P "randomly"
End_P = End_P_ini; End_P = End_P + (rand()-1/2)*2*End_P_range;
if End_P < 0.4
    End_P = rand()/5+0.4;
end

% vary Bulk_Comp "randomly"
Bulk_Comp = Bulk_ini;

Bulk_Comp(1) = Bulk_Comp(1) + (rand()-1/2)*2 * Bulk_Comp(1) * 0.03;
Bulk_Comp(3) = Bulk_Comp(3) + (rand()-1/2)*2 * Bulk_Comp(3) * Bulk_range1;
Bulk_Comp(5) = Bulk_Comp(5) + (rand()-1/2)*2 * Bulk_Comp(5) * Bulk_range0;
Bulk_Comp(8) = Bulk_Comp(8) + (rand()-1/2)*2 * Bulk_Comp(8) * Bulk_range2;
Bulk_Comp(7) = Bulk_Comp(7) + (rand()-1/2)*2 * Bulk_Comp(7) * Bulk_range0;
Bulk_Comp(2) = Bulk_Comp(2) + (rand()-1/2)*2 * Bulk_Comp(2) * Bulk_range1;
Bulk_Comp(9) = Bulk_Comp(9) + (rand()-1/2)*2 * Bulk_Comp(9) * Bulk_range2; 
Bulk_Comp(10) = Bulk_Comp(10) + (rand()-1/2)*2 * Bulk_Comp(10) * Bulk_range2;

Bulk_Comp = Bulk_Comp./sum(Bulk_Comp)*100; % renormalize Bulk...

%now run model with modified composition and End_P
[Final_table] = MAGMARS_v1('DW',Start_P,End_P,Bulk_Comp,0.004,Tp_poly(1),Tp_poly(2),Tp_poly(3),Iso_mode,KD,T_continuous,plotit);

Tp_profileR = Tp_profile(size(Tp_profile,2)-size(Final_table.data,1)+1:end)';
allm(i).Final_table=[Tp_profileR Final_table.data];
allm(i).Bulk_Comp=Bulk_Comp;
allm(i).End_P=End_P;
close(figure(9))
end

save(FName_poly, 'allm')
clear allm

%% isobaric melting
Iso_mode= 1; % 1 - isobaric
Tp_profile=Tp_iso(1):Tp_iso(2):Tp_iso(3); Tp_profile=[NaN Tp_profile];
for i=1:simulN
% vary End_P "randomly"
Start_P = Start_P_iso; Start_P = Start_P + (rand()-1/2)*2*P_iso_range;
End_P = Start_P;

% select same bulk comp as for isobaric
Bulk_Comp = Bulk_ini;

Bulk_Comp(1) = Bulk_Comp(1) + (rand()-1/2)*2 * Bulk_Comp(1) * 0.03;
Bulk_Comp(3) = Bulk_Comp(3) + (rand()-1/2)*2 * Bulk_Comp(3) * Bulk_range1;
Bulk_Comp(5) = Bulk_Comp(5) + (rand()-1/2)*2 * Bulk_Comp(5) * Bulk_range0;
Bulk_Comp(8) = Bulk_Comp(8) + (rand()-1/2)*2 * Bulk_Comp(8) * Bulk_range2;
Bulk_Comp(7) = Bulk_Comp(7) + (rand()-1/2)*2 * Bulk_Comp(7) * Bulk_range0;
Bulk_Comp(2) = Bulk_Comp(2) + (rand()-1/2)*2 * Bulk_Comp(2) * Bulk_range1;
Bulk_Comp(9) = Bulk_Comp(9) + (rand()-1/2)*2 * Bulk_Comp(9) * Bulk_range2; 
Bulk_Comp(10) = Bulk_Comp(10) + (rand()-1/2)*2 * Bulk_Comp(10) * Bulk_range2;
Bulk_Comp = Bulk_Comp./sum(Bulk_Comp)*100; % renormalize Bulk...

% now run model with modified composition and End_P
[Final_table] = MAGMARS_v1('DW',Start_P,End_P,Bulk_Comp,0.004,Tp_iso(1),Tp_iso(2),Tp_iso(3),Iso_mode,KD,T_continuous,plotit);

Tp_profileR = Tp_profile(size(Tp_profile,2)-size(Final_table.data,1)+1:end)';
allm(i).Final_table=[Tp_profileR Final_table.data];
allm(i).Bulk_Comp=Bulk_Comp;
allm(i).End_P=End_P;
close(figure(9))
end

save(FName_iso, 'allm')
toc
