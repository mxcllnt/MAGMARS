close all;
%              SiO2     TiO2    Al2O3   Cr2O3   FeO     MnO     MgO     CaO     Na2O    K2O     P2O5
Bulk_Comp =   [44.10	0.13	3.02	0.76	17.90	0.46	31.21	2.49	0.50	0.04	0.16]; %DW85

Tp_min = 1050;
Tp_inc = 50;
Tp_max = 1550;
P = 0.5:0.045:5;

Start_P = 5.5; % zone where melting is allowed 
End_P = 1;
Iso_P = 2.5; % pressure for isobaric melting

Iso_mode = 0; % 0 - polybaric | 1 - isobaric;
plotit = 1; % plot the graph = 1, set to =0 for faster calculation

% those usually don't need to be adjusted 
CMF = 0.004; % critical melt fraction, keep between 0.004 and 0.02
KD = [4, 0.35]; % recommended
T_continuous = [0 1300]; % 1 = force T continuous (Harzburgite thermometer); 0 only force T continuous above T_continuous(2)

if Iso_mode == 1
    Start_P = Iso_P;
    End_P = Iso_P;
end
tic
[Final_table1,detail_comp] = MAGMARS_v1('DW',Start_P,End_P,Bulk_Comp,CMF,Tp_min,Tp_inc,Tp_max,Iso_mode,KD,T_continuous,plotit);
toc