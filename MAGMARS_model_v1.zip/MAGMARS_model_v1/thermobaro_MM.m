% place liquid for which you want to estimate the P-T as 11 oxide vectors
% SiO2 TiO2 Al2O3 Cr2O3 FeO MnO MgO CaO Na2O K2O P2O5
% Printout and save (thermobarometer.txt) the following thermobarometer results: 
% (1) recommended P-independant thermometer (this study)
% (2) recommended barometer (this study, Lee et al. 2009 recal)
% (3) MAGMARS harzburgite melting thermometer (P dependant, this study)
% (4) thermometer eq. 15 from Putirka 2008
% (5) oliv-liq thermometer AB from Putirka 2005 
% (6) oliv-liq thermometer AB, recalibrated (this study)
% (7) Barometer from Lee et al. 2009

Liq =[46.04	0.54	10.37	0.62	19.17	0.42	11.91	7.94	2.33	0.08	0.58
45.85	0.53	10.10	0.60	19.24	0.41	12.62	7.74	2.27	0.08	0.57
44.99	0.46	8.83	0.53	19.26	0.36	16.27	6.76	1.98	0.07	0.49];

% calculate cation and molar compositions used in some thermobarometers
MMCat = [60.084 79.878 50.981 75.995 71.8464 70.937 40.3045 56.079 30.990 47.098 70.972];
MM = MMCat.*[1 1 2 2 1 1 1 1 2 2 2];
Liq_cat = Liq./MMCat;
Liq_cat = Liq_cat./sum(Liq_cat')';
Liq_mol = Liq./MM;
Liq_mol = Liq_mol./sum(Liq_mol')'*100;
MgN_liq = Liq_mol(:,7)./(Liq_mol(:,7)+Liq_mol(:,5));
%% model AB Putirka 2005 (only Fe-Mg partitioning)
T=[900:1900];
T_AB = NaN*ones(size(Liq_cat,1),1);
for i=1:size(Liq_cat,1)
Catsum = Liq_cat(i,7).*exp(-2.02+4490.5./T) + Liq_cat(i,5).*exp(-2.66+3793.3./T);
idx=find(abs(Catsum-0.6667) == min(abs(Catsum-0.6667)));
T_AB(i)=T(idx);
end
%% model AB - recalibrated (this study)
T_AB_C21 = NaN*ones(size(Liq_cat,1),1);
for i=1:size(Liq_cat,1)
Catsum = Liq_cat(i,7).*exp(-2.6057+5188.5./T) + Liq_cat(i,5).*exp(-3.5713+5070.7./T);
idx=find(abs(Catsum-0.6667) == min(abs(Catsum-0.6667)));
T_AB_C21(i)=T(idx);
end
%% P-independant thermometer (this study) 
 T_coeff =[209.2
        4.81
       20.86
        3.03
       10.17
        16.97
       -6.97];
  
   T_Pind = T_coeff(1).*ones(size(Liq(:,1),1),1) + T_coeff(2).*MgN_liq.*100 + T_coeff(3).*(Liq(:,5)+Liq(:,7)) + T_coeff(4).*Liq(:,1) +  ...
        + T_coeff(5).*Liq(:,3) + T_coeff(6).*(Liq(:,9)+Liq(:,10)) + T_coeff(7).*Liq(:,11);   
%% Barometer of Lee et al. 2009
Si4O8 = 0.25 .* (Liq_mol(:,1) - 0.5 .* (Liq_mol(:,5)+Liq_mol(:,7)+Liq_mol(:,8)) - Liq_mol(:,9) - Liq_mol(:,10));
Ti4O8 = 0.25 .* Liq_mol(:,2);
Al4O8 = 0.375 .* (Liq_mol(:,3)-Liq_mol(:,9));
Cr4O8 = 0.375 .* Liq_mol(:,4);
Fe4O8 = 0.25 .* Liq_mol(:,5);
Mn4O8 = 0.25 .* Liq_mol(:,6);
Mg4O8 = 0.25 .* Liq_mol(:,7);
Ca4O8 = 0.25 .* Liq_mol(:,8);
Na4O8 = Liq_mol(:,9);
K4O8 = Liq_mol(:,10);
P4O8 = 0.625 .* Liq_mol(:,11);
mol_spec = [Si4O8 Ti4O8 Al4O8 Cr4O8 Fe4O8 Mn4O8 Mg4O8 Ca4O8 Na4O8 K4O8 P4O8];
mol_spec = mol_spec ./ sum(mol_spec')'.*100;
P_Lee = (log(mol_spec(:,1))-4.019+0.0165.*mol_spec(:,5)+0.0005.*mol_spec(:,8).^2) ...
        ./(-770.*(T_AB+273.15).^-1. + 0.0058.*(T_AB+273.15).^(1/2));
%% New barometer recalibrated (similar to Lee et al. 2009)

P_LeeN2 = (log(mol_spec(:,1))-4.24+0.0185.*mol_spec(:,5)+0.0109.*mol_spec(:,8)+0.009.*mol_spec(:,11)) ...
          ./(-800.*(T_Pind).^-1. + 0.0075.*(T_Pind).^(1/2));
%% MAGMARS thermometers (lherzolite and harzburgite melting) 

[SiO2_coeff,SiO2_coeff2,CaO_coeff,CaO_coeff2,FeO_coeff,FeO_coeff2,MgO_coeff,MgO_coeff2,Cr2O3_coeff,Cr2O3_coeff2,T_coeff,T_coeff2] = MM_reg(0);

T_lherz = [ones(size(Liq(:,1),1),1) P_LeeN2 MgN_liq.*100 Liq(:,3) Liq(:,9)+Liq(:,10) Liq(:,11)]*T_coeff;
T_harz = [ones(size(Liq(:,1),1),1) P_LeeN2 MgN_liq.*100 Liq(:,3) Liq(:,9)+Liq(:,10) Liq(:,11)]*T_coeff2;
%% Putirka eq.15

P1 = 815.3; %cst
P2 = 39.16; %P
P3 = 2.655; %Mg#
P4 = 6.646; %Na2O+K2O
P5 = 8.61;  %FeO
P6 = 15.37; %MgO

T_P15 = P1.*ones(size(Liq(:,1),1),1) + P2.*P_LeeN2 + P3.*MgN_liq.*100 ...
        + P4.*(Liq(:,9)+Liq(:,10)) + P5.*Liq(:,5) + P6.*Liq(:,7);
%%    
format shortG    
TP_summary = [T_Pind P_LeeN2 T_harz T_P15 T_AB T_AB_C21 P_Lee]

TP.labelsForm = '%16s %16s %10s %16s %12s %16s %16s\n';
TP.dataForm = '%16.0f %16.1f %10.0f %16.0f %12.0f %16.0f %16.1f\n';

fileID = fopen(['thermobaro' '.txt'],'w');
fprintf(fileID,TP.labelsForm,'T (recommended)','P (recommended)','T harz','T P08 eq.15','T AB P05','T AB (recal)','P L09');
fprintf(fileID,TP.dataForm,TP_summary');
fclose(fileID);